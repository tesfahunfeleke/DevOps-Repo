School-managment-system-database
================================
Databases, queries, functions and Procedures for school managment system for MySQL
